package com.bridgelabz.fundoonotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundoonotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
