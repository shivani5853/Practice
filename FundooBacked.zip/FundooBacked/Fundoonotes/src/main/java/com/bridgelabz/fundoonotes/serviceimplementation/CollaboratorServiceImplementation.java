package com.bridgelabz.fundoonotes.serviceimplementation;

import org.springframework.stereotype.Service;

import com.bridgelabz.fundoonotes.service.CollaboratorServiceInf;

@Service
public class CollaboratorServiceImplementation implements CollaboratorServiceInf{

}
