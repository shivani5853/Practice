package com.bridgelabz.fundoonotes.exception;

public class LabelException {
	
}
