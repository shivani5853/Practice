package com.bridgelabz.fundoonotes.dto;

public class CollaboratorDto {

}
