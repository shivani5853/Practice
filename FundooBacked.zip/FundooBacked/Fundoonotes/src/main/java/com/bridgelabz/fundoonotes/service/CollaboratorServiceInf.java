package com.bridgelabz.fundoonotes.service;

public interface CollaboratorServiceInf {

}
