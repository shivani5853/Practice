/******************************************************************************
 *  Purpose: Utility
 *
 *  @author  Shivani Kumari
 *  @version 1.0
 *  @since   29-12-2019
 *
 ******************************************************************************/

/*
 * PACKAGE NAME
 */
package com.bridgelabz.fundoonotes.utility;

/*
 * IMPORT STATEMENTS
 */

public class Utility {

}