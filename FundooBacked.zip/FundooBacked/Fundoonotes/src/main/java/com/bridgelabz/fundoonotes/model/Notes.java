package com.bridgelabz.fundoonotes.model;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "notes")
public class Notes {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Note_Id")
	private Long noteId;

	@Column(name = "Title")
	@NotEmpty(message = "Invalied Title")
	private String title;

	public Long getNoteId() {
		return noteId;
	}

	public void setNoteId(Long noteId) {
		this.noteId = noteId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsPinned() {
		return isPinned;
	}

	public void setIsPinned(Boolean isPinned) {
		this.isPinned = isPinned;
	}

	public Boolean getIsArchive() {
		return isArchive;
	}

	public void setIsArchive(Boolean isArchive) {
		this.isArchive = isArchive;
	}

	public Boolean getIsTrash() {
		return isTrash;
	}

	public void setIsTrash(Boolean isTrash) {
		this.isTrash = isTrash;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public LocalDateTime getReminderTime() {
		return reminderTime;
	}

	public void setReminderTime(LocalDateTime reminderTime) {
		this.reminderTime = reminderTime;
	}

	public String getReminder() {
		return reminder;
	}

	public Notes(Long noteId, @NotEmpty(message = "Invalied Title") String title, String description, Boolean isPinned,
			Boolean isArchive, Boolean isTrash, LocalDateTime createdAt, String colour, Date updateTime,
			LocalDateTime reminderTime, String reminder, User noteUser, boolean isVerified, List<Labels> labels) {
		super();
		this.noteId = noteId;
		this.title = title;
		this.description = description;
		this.isPinned = isPinned;
		this.isArchive = isArchive;
		this.isTrash = isTrash;
		this.createdAt = createdAt;
		this.colour = colour;
		this.updateTime = updateTime;
		this.reminderTime = reminderTime;
		this.reminder = reminder;
		this.noteUser = noteUser;
		this.isVerified = isVerified;
		this.labels = labels;
	}

	public Notes() {
		super();
	}

	public void setReminder(String reminder) {
		this.reminder = reminder;
	}

	public User getNoteUser() {
		return noteUser;
	}

	public void setNoteUser(User noteUser) {
		this.noteUser = noteUser;
	}

	public boolean isVerified() {
		return isVerified;
	}

	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}

	public List<Labels> getLabels() {
		return labels;
	}

	public void setLabels(List<Labels> labels) {
		this.labels = labels;
	}

	@Column(name = "Description")
	private String description;

	@Column(columnDefinition = "boolean default false")
	private Boolean isPinned;

	@Column(columnDefinition = "boolean default false")
	private Boolean isArchive;

	@Column(columnDefinition = "boolean default false")
	private Boolean isTrash;

	@Column(name = "CreatedAt")
	@DateTimeFormat
	private LocalDateTime createdAt;

	@Column(columnDefinition = "varchar(10) default 'ffffff'")
	private String colour;

	@Column(name = "UpdateTime")
	@DateTimeFormat
	private Date updateTime;

	@Column(name = "reminderTime")
	private LocalDateTime reminderTime;

	@Column(name = "reminder")
	private String reminder;

	@ManyToOne
	@JoinColumn(name = "userId")
	private User noteUser;

	@Column(columnDefinition = "boolean default false")
	private boolean isVerified;

	public Notes(String title, String description) {
		this.title = title;
		this.description = description;
	}

	public void setupdateTime() {
		this.updateTime = new Date();
	}

	@ManyToMany
	@JoinTable(name = "Label_Note", joinColumns = @JoinColumn(name = "note_id", referencedColumnName = "note_id"), inverseJoinColumns = @JoinColumn(name = "label_note_id", referencedColumnName = "label_id"))
	private List<Labels> labels;

}
