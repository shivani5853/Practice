package com.bridgelabz.fundoonotes.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Setter
//@Getter
//@NoArgsConstructor
//@AllArgsConstructor
public class LabelDto {
	public String getLableName() {
		return lableName;
	}
	public void setLableName(String lableName) {
		this.lableName = lableName;
	}
	public long getLabelId() {
		return labelId;
	}
	public LabelDto() {
		super();
	}
	public LabelDto(String lableName, long labelId) {
		super();
		this.lableName = lableName;
		this.labelId = labelId;
	}
	public void setLabelId(long labelId) {
		this.labelId = labelId;
	}
	private String lableName;
	private long labelId;
}
