package com.bridgelabz.fundoonotes.dto;

import java.time.LocalDateTime;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Data
//@Setter
//@Getter
//@NoArgsConstructor
//@AllArgsConstructor
public class ReminderDto {
	public String getReminderStatus() {
		return reminderStatus;
	}
	public void setReminderStatus(String reminderStatus) {
		this.reminderStatus = reminderStatus;
	}
	public LocalDateTime getReminder() {
		return reminder;
	}
	public ReminderDto() {
		super();
	}
	public ReminderDto(String reminderStatus, LocalDateTime reminder) {
		super();
		this.reminderStatus = reminderStatus;
		this.reminder = reminder;
	}
	public void setReminder(LocalDateTime reminder) {
		this.reminder = reminder;
	}
	private String reminderStatus;
	private LocalDateTime reminder; 
}
